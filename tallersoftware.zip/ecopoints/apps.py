from django.apps import AppConfig


class EcopointsConfig(AppConfig):
    name = 'ecopoints'
